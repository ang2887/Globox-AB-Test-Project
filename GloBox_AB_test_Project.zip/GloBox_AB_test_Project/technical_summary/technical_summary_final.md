# A/B Test Report: Food and Drink Banner

## Purpose
The purpose of A/B test is to evaluate the effectiveness of a new banner showcasing key product  
in the drink and food category on GloBox's mobile website.  
The goal is to determine whether displaying this banner to users leads to a significant increase<br>
in conversions, particularly in the food and drink category.<br>


## Hypotheses

**1. Difference in the conversion rates:**
**Null Hypothesis (H0):** There is no difference in the conversion rates between users who see
the food and drink banner (test group A) and those who do not (control group B).

**Alternative Hypothesis (H1):** There is a statistically significant difference in the conversion rates
between the test and control groups.

**2. Difference in average amount spent per user:**
**Null Hypothesis (H0):** There is no difference in average amount spent per user between users who
see the food and drink banner (test group A) and those who do not (control group B).

**Alternative Hypothesis (H1):** There is a statistically significant difference in the average amount spent
per user between the test and control groups.

## Methodology
### Test Design
- **Population:** 
**Group A: Control:** Users randomly assigned to the control group do not see the food and drink banner
when accessing the GloBox main page on the mobile website.
This group serves as the baseline or control condition, allowing for a comparison against the test group.

**Group B: Treatment :** Users randomly assigned to the test group experience the A/B test condition, 
where they see the food and drink banner when visiting the GloBox main page on the mobile website. 
This group represents individuals exposed to the experimental condition.

- **Duration:** 
Start date: January 25, 2023 
End date:   February 6, 2023
- **Success Metrics:** 
Conversion rate, average amount spent per user

## Results
### Data Analysis
- **Pre-Processing Steps:** I wrote the following SQL queries.
This is #1 query for obtaining the final analysis daataset.
The codes #2, #3 and #4 in the ## Appendix below

Query # 1

```sql

/* This query analyses user activity and group assignment data to understand conversion rates
and spending behavior, categorising users into Control and Treatment groups. */

WITH converted AS(
 -- Calculate total spent per user and determine conversion status.
 SELECT u.id,
         SUM(COALESCE(a.spent, 0)) AS spent_per_user,
         -- Converted is 1 if 'spent' is greater than 0, otherwise 0.
         CASE WHEN a.spent > 0 THEN 1 ELSE 0 END AS converted 
 FROM users u
    LEFT JOIN activity a ON u.id = a.uid
GROUP BY u.id,
         converted
),

test_group AS(
 -- Categorise users into Control and Treatment groups based on their assigned group.
	SELECT g.uid,
         -- 'A' group is Control, other -'B' -is Treatment.
         CASE WHEN g.group = 'A' THEN 'Control' ELSE 'Treatment' END AS test_group 
	FROM groups g
)

-- Main query selects user attributes, group assignment, conversion status, and spending behavior.
SELECT u.id,
      -- Replace NULL values in country, gender, and device with 'Unknown'.
      COALESCE(u.country, 'Unknown') AS country,
      COALESCE(u.gender, 'Unknown') AS gender,
      COALESCE(g.device, 'Unknown') AS device,
      t.test_group AS test_group,
      -- Indicates conversion status (1 for converted, 0 for not converted).
      c.converted AS converted,
      c.spent_per_user AS spent_per_user
FROM users u
 LEFT JOIN groups g ON u.id = g.uid
 LEFT JOIN test_group t ON u.id = t.uid
 LEFT JOIN converted c ON u.id = c.id
 
ORDER BY u.id;


```

- **Statistical Tests Used:**
Two-sample z-test for comparing conversion rates.
Two-sample t-test for comparing the average amount spent per user.

Two-sample z-interval for a difference in proportions.
Two-sample t-interval for a difference in means.

- **Results Overview:** 
The statistical analysis revealed statisticaly confirmed  difference in conversion rates
between the test and control groups.

There was not statisticaly confirmed  difference in the average amount spent per user 
between the test and control groups.

### Findings
Detailed findings from the statistical tests are as follows:

**Conversion rates:**
Significance level set at 0.05
p-value  for conversion rate: 0.0001  
p-value < 0.05, rejecting the null hypothesis.

Effect size for difference in proportions was measured using Cohen's h.
Effect size for difference in conversion rates: 0.034971329736304124. This points to a small change.

MDE set at 10% (0.1)
Confidence interval for conversion rate with  
lower bound 0.0034860511629807105 
upper bound 0.010653593996359
falls below the threshold of practical significance. 

Relative lift for Conversion Rate:  18.02101477035713. With the predetermined MDE of 10%(0.1) 
indicates meaningful - moderate  - improvement.

**Average Amount Spent**
Significance level set at 0.05
p-value for average spent:  0.9438560436782033 
p-value > 0.05, failing to reject the null hypothesis.

Effect size for difference in means was measured using Cohen's d
Effect size for difference in average amount spent per user:  0.000636707816673343. 
This points to a neglidible change.


MDE set at 10% (0.1)
Confidence interval for average spent:  -0.43866128111980446 0.4713582370336881
This interval contains 0, which indicates lack of statistacal evidence.
Upper bound of 0.4713582370336881 exceeds the set MDE of 0.1 by significant margin. Notehworthy.

Relative lift spent:  0.4844684689776181. Since difference in means is not proved statistically, 
this value might not be reliabe.


_Given the absence of information on product categories, the following analysis is preliminary._
_It must be revisited in greater depth following the update on both non-food and food and drink sectors._

**Price Groups:** 
My focus is on the $100 and $200 price range group of customers, 
as 51.51% of customers in the control group generate 41.3% of total revenue. 
In the treatment group, there is a *decline* in total revenue where 41.79% of customers 
generated 33.3% of total revenue.

**Device:** 
The Unknown group, generating only 0.89% of revenue, has been excluded. 

Revenue generated by IOS devices in the control group is *higher* at 57% against Android's 42.88%. 
There is a *prevalence* of Android devices across all countries.

_Conversion Rate per Device:_
*	Android in the treatment group *growth* by 27.25%.
*	IOS in the treatment group *growth* by 10.48%.

_Average Amount Spent per Device:_
*	Android in the treatment group experiences a *growth* of 6.63%.
*	IOS in the treatment group sees a *decline* of -3.03%.


**Gender:** 
Comprising 18.02% of the total revenue, the combined contribution from the Unknown category 
and Other category is noteworthy and warrants further investigation. 

To obtain an approximate understanding of the total revenue distribution between 
female and male groups, these categories(Unknown and Other) were excluded from the initial analysis.

Total Revenue percentage between Male and Female Groups:
*	Female group: *Decline* from 66.52% (Control) to 60.95% (Treatment).
*	Male group: *Growth* from 33.48% (Control) to 39.05% (Treatment).

_Conversion Rate:_
*	Female group in the treatment group *growth* by 5.68%.
*	Male group in the treatment group sees *growth* by 44.37%.

_Average Amount Spent across Female and Male Groups:_
*	Female group in the treatment group experiences a *decline* of -7.46%.
*	Male group in the treatment group sees impressive *growth* of 15.61%.


**Country:** 
The Unknown country category, contributing only 1.3% of total revenue, was excluded from the analysis. 
Maximum revenue was generated by the USA at 37.32%.

_Conversion Rate:_
*	Maximum *growth* was observed in Mexico at +50.84%.
*	Turkey was the only country showing a *decline* in the conversion rate at -11.09%.

_Average Amount Spent by Country Category:_
*	Maximum average amount spent is observed in Great Britain at +113%.
*	*Decline* in average amount spent is observed in Brazil, USA, France, Germany, and Turkey, 
with the most significant *drop* being noted in  Turkey at -32.56%.

_Correlation:_ A *strong correlation* between the conversion rate and average amount spent per country 
is indicated by an R-squared value of 0.786. 
Outliers include GBR (Great Britain) with the *highest* average spent by conversion rate, 
while Australia, France, and Canada exhibit the *lowest* average spending by conversion rate ratio.


**Region:** 
Ten countries—Australia, Brazil, Canada, Germany, Spain, France, Great Britain, Mexico, Turkey, 
and the USA—have been divided into four regions: North America, South America, Australasia, and Europe. 
Notably, Turkey is geographically located in both Europe and Asia.

_Conversion Rate:_
*	Maximum growth is observed in Australasia at 41.98%.
*	Minimum growth is observed in North America at +14.62%.

_Average Amount Spent:_
*	Maximum is observed in Australasia at 24.71%.
*	Minimum is observed in Europe at 1.71%.
*	Decline is observed in North America at -3.83%.

**To sum up negative tendencies**

* In the treatment group, there is a decline in *total revenue*, with 41.79% of customers 
  generating 33.3% of the total revenue.
* *IOS devices* in the treatment group experience a decline of -3.03%.
* Total revenue percentage between male and female groups shows a decline from 66.52% to 60.95% 
  for the *female group* in the treatment.
* The *female group* in the treatment also experiences a decline of -7.46% in average amount spent.
* *Turkey* exhibits a unique decline in both conversion rate (-11.09%) and average amount spent (-32.56%).
* Other countries, including *Brazil, USA, France, and Germany*, also show a decline in average amount spent.
* *Australia, France, and Canada* exhibit the lowest average spending by conversion rate ratio.


## Interpretation
- **Outcome of the Test(s):** 
The results support the hypothesis that displaying the food and drink banner significantly increases 
conversion rates. However, there is no evidence of a significant difference in the average amount spent per user.

The consistent negative trend in the amount spent across different categories and groups emphasises 
the importance of further investigation to comprehend the underlying factors contributing to these declines. 
This exploration will provide valuable insights for informing potential optimization strategies.


- **Confidence Level:** 
The tests were conducted at a 95% confidence level.

## Conclusions
- **Key Takeaways:** 
The food and drink banner positively influences user conversions, suggesting it is an effective feature. 
However, it does not significantly impact the average amount spent per user from a statistical point of view. 

While customer engagement appears promising, further investigation is required
to identify and address factors that may be hindering customer interest in making purchases.
It is especially obvious in Male Gender category where the treatment group shows an impressive 44.37% growth 
in conversion rate, with disproportioned 15.61 % increase in average amount spent.
This is undeniable hint to concurrent hindrance preventing a parallel increase.



- **Limitations/Considerations:** 
  1. Insufficient historical data is limiting our ability to address fluctuations in the total number of customers
     and impacting the accuracy of forecasting user numbers over an extended period.
  2. Not sufficient amount of users for 80% statistical power 
     (see the link for sample size calculators in Appendix section).
  3. The lack of information on product categories poses a challenge in our analysis as we currently
     cannot discern the specific impact of the new banner on the food and drink category. 
  


## Recommendations
- **Next Steps:** 

Given: 

1. The abrupt decline in total customers (from 11646 to 1274 )
   and total revenue (from $38 332 to $4483) during a 13-day test(from 2023-01-25 to 2023-02-06)
2. Absence of statistically meaningful increase in the average amount spent per user metric
3. Unsufficient number of users for the statistical power of the test of 80%
4. Lack of specified segmentation for products categories 

I recommend  to analyse historical data to determine if similar patterns 
in decline in the number of customers resulting in a significant impact on total revenue,
occurred in previous years, providing context and insights into potential business threats.


- **Further Analysis:**

If historical analysis confirms a recurring pattern with no identified threats to the business, 
I recommend **rerunning** the test with an updated setup to explore further insights 
and potential improvements with:

1. **Increased number of users** to 77,000.

2. **Extended duration of the test** to gain a more profound understanding of trends over time regarding 
   new vs. existing customer behaviour. The estimated duration will be available only after conducting
   historical data analysis, as we do not yet know the pattern of fluctuations for customer numbers in previous years.

3. **Thorough analysis of product-related aspects**, including website usability, pricing strategies, 
   product information accuracy, product availability, concurrent or ongoing promotions for different categories, 
   and customer feedback. Additionally, investigating checkout process optimisation and potential technical issues 
   can offer insights into the factors hindering the translation of increased conversion rates into revenue growth.

4. **Segmentation details for the food category and non-food categories**, crucial for gaining insights 
   into customer behaviour, preferences, and purchase patterns, ultimately informing targeted strategies and optimisations.

5. **Further investigation into the 'Unknown' and 'Other'** categories.

6. **Behaviour and characteristics analysis** of the customer segment in the treatment group responsible 
   for the decline in total revenue, with a focus on surveys.

7. **Investigation of issues affecting iOS users**, including any technical issues.

8. **Analysis of factors influencing the decline among females** regarding product preferences and pricing strategies, 
   with a focus on surveys.

9. ***Detailed analysis of Turkey separately** given the atypical decline observed in both conversion rate 
   and the significant decrease in the average amount spent.

10. **Identify commonalities among countries experiencing a decline** – Turkey, Brazil, USA, France, and Germany, 
    as well as among countries with a lower spending ratio – Australia, France, and Canada.

11. **Exploring potential cultural differences** may provide insights into the observed unusual trends across countries. 

12. **Applying the same approach for regions**.


## Appendix 

Query # 2

```sql

/* This query analyses the spending behaviour of users categorised into 
Control and Treatment groups during the test period, 
focusing on the evolution of purchase behaviour over time. */
WITH converted AS(
 -- CTE to calculate total spent per user and determine their conversion status.
   SELECT u.id,
          SUM(COALESCE(a.spent, 0)) AS spent_per_user,
          -- Converted is 1 if 'spent' is greater than 0, otherwise 0
          CASE WHEN a.spent > 0 THEN 1 ELSE 0 END AS converted

  FROM users u
  LEFT JOIN activity a ON u.id = a.uid

 GROUP BY u.id, converted
),

test_group AS(
 -- Categorise users into Control and Treatment groups based on their assigned group.
   SELECT g.join_dt AS date,
         g.uid AS uid,
         -- 'A' group is Control, other ('B') is Treatment
         CASE WHEN g.group = 'A' THEN 'Control' ELSE 'Treatment' END AS test_group

  FROM groups g

  GROUP BY date, 
          uid, 
          test_group
),

info_by_date AS(
/* Aggregate number of converted users and their spending data by date and test group, 
  preparing for final analysis. */
  SELECT tg.date AS date,
         tg.test_group AS test_group,
         tg.uid AS id,
         SUM(c.converted) AS converted,
         c.spent_per_user AS spent_per_user
  FROM test_group tg

  LEFT JOIN converted c ON tg.uid = c.id

  GROUP BY date,
          test_group,
          tg.uid,
          converted,
          spent_per_user
)

/* The final query presents a summary of the total number of users, 
the count of users who have made a purchase (indicated by the 'converted' column), 
and the overall spending, offering insights into how user conversion and spending trends 
have varied across different groups and over the course of the test period. */
SELECT ibd.date,
       ibd.test_group,
       COUNT(DISTINCT ibd.id) AS num_id,
       SUM(ibd.converted) AS num_converted,
       SUM(ibd.spent_per_user) AS total_spent

FROM info_by_date ibd

GROUP BY ibd.date,
         ibd.test_group
ORDER BY date
;

```

Query # 3

```sql

-- Query to analyse the trend of customer counts over the trial period.
WITH test_group AS(
-- CTE to categorise users into Control and Treatment groups based on their group assignment date.  
  SELECT g.join_dt AS date,
         g.uid AS uid, 
        -- Assign 'Control' to users in group 'A', and 'Treatment' to users in other - 'B'- group.
         CASE WHEN g.group = 'A' THEN 'Control' ELSE 'Treatment' END AS test_group
  
  FROM groups g
 -- Group by date, user ID, and test group to ensure unique combinations for each user's group assignment.
  GROUP BY date, uid, test_group
)  

/* Main query to count the number of customers in each test group, categorised by date,
to gain insights into the trend of customer counts over time. */
SELECT tg.date AS date,
       tg.test_group AS test_group,
       -- Count distinct user IDs to get the total number of customers in each test group for each date.
       COUNT(DISTINCT tg.uid ) AS num_customers
       
FROM test_group tg

GROUP BY date, test_group
-- Results ordered by date to provide a chronological overview of the customer counts in each test group.
ORDER BY date
;

```

Query # 4

```sql

/* Query to find point estimate, lower bound, and upper bound for both conversion rate
and average amount spent for Control and Treatment test groups of users */
WITH converted AS(
-- CTE to categorise users into Control and Treatment groups based on their group assignment data. 
  SELECT u.id,
         SUM(COALESCE(a.spent, 0)) AS spent_per_user,
         CASE WHEN a.spent > 0 THEN 1 ELSE 0 END AS converted

   FROM users u  
      LEFT JOIN activity a ON u.id = a.uid

 GROUP BY u.id, converted

),
test_group AS(
-- Assign 'Control' to users in group 'A', and 'Treatment' to users in other -'B'- group.  
   SELECT g.uid,
         CASE WHEN g.group = 'A' THEN 'Control' ELSE 'Treatment' END AS test_group 

   FROM groups g

   GROUP BY g.uid 
)
/* Main query calculates the point estimate, lower bound, and upper bound for both 
conversion rate and average amount spent per each Control and Treatment test groups of users */
SELECT  AVG(c.spent_per_user) AS point_est_spent,
        AVG(c.spent_per_user) + 1.6* STDDEV(c.spent_per_user)/(SQRT(COUNT(*))) AS upper_bound_spent,
        AVG(c.spent_per_user) - 1.6* STDDEV(c.spent_per_user)/(SQRT(COUNT(*))) AS lower_bound_spent,
        (SUM(c.converted)/COUNT(DISTINCT u.id)::FLOAT)*100 AS point_est_conv_rate,
        (AVG(c.converted) + 1.6* STDDEV(c.converted)/(SQRT(COUNT(*))))*100 AS upper_bound_conv_rate,
        (AVG(c.converted) - 1.6* STDDEV(c.converted)/(SQRT(COUNT(*))))*100 AS lower_bound_conv_rate, 
        tg.test_group
      
FROM users u
   LEFT JOIN converted c ON u.id = c.id
   LEFT JOIN test_group tg ON c.id = tg.uid
 
GROUP BY tg.test_group
;

```

[This is Colab Python notebook link](https://drive.google.com/drive/folders/1rCWirz5UkWQNW2AuRAFYctGEG2J2pVpQ?usp=drive_link)

[This is tableau public link](https://public.tableau.com/views/GloBox_viz/49_TotalAmountSpentperDaydrop88_3?:language=en-GB&:sid=&:display_count=n&:origin=viz_share_link)

[This is sample size calculator for a difference in proportions link](https://www.statsig.com/calculator)

[This is sample size calculator for a difference in means link](https://statulator.com/SampleSize/ss2M.html)


























