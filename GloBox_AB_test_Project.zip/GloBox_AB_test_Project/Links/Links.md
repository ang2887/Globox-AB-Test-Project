
# **Resource links**

Check out my [Python notebook link](https://drive.google.com/drive/folders/1rCWirz5UkWQNW2AuRAFYctGEG2J2pVpQ?usp=drive_link)

Check out my [Tableau public link](https://public.tableau.com/views/GloBox_viz/49_TotalAmountSpentperDaydrop88_3?:language=en-GB&:sid=&:display_count=n&:origin=viz_share_link)

Check out my [Presentation video link](https://1drv.ms/p/c/a5a36a4b590607f0/ER5fPkvnbGdMjjv88cRtfqIBSS3ICdFoIYrjxBEvecNS3Q)
